
Faces_dataset - v1 2020-12-07 2:07am
==============================

This dataset was exported via roboflow.ai on December 7, 2020 at 1:08 AM GMT

It includes 981 images.
Face are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 42 percent of the image
* Random rotation of between -26 and +26 degrees


